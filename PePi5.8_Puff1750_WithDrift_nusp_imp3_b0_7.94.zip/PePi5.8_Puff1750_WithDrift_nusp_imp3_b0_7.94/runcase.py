import sys
import numpy as np
import matplotlib.pyplot as plt
from uedge import *
from uedge.hdf5 import *
from uedge.rundt import *



def setGrid():

    bbb.gengrid=0
    bbb.mhdgeo = 1          #use MHD equilibrium
    com.geometry = "snull"
    com.nxpt=1    #-how many X-points in the domain
    #isnonog=1
    methg=66


    #bbb.gallot("Xpoint_indices",0)
    #grd.readgrid("gridue",com.runid)

    com.nx=com.nxm
    com.ny=com.nym
    com.isnonog = 0

    # Finite-difference algorithms (upwind, central diff, etc.)
    bbb.methn = 33          #ion continuty eqn
    bbb.methu = 33          #ion parallel momentum eqn
    bbb.methe = 33          #electron energy eqn
    bbb.methi = 33          #ion energy eqn
    #bbb.methg = 33 #66          #neutral gas continuity eqn
    bbb.methg=33


def setPhysics(impFrac=0.0, b0=1.0, fluxLimit=False):
    bbb.mfnksol = 3		# default is -3
    bbb.epscon1 = .005		# default is 0.1
    bbb.iscolnorm = 3		# default, OK
    bbb.ftol = 1.e-9		# default is 1.e-10
    bbb.rlx = 0.4		# default, OK
    bbb.delpy = 1.e-9		# default is 1.e-7
    bbb.del2nksol = 1.e-14	# default, OK
    bbb.premeth = "ilut"	# default is "ilut"
    bbb.lenpfac = 60		# default, OK
    bbb.lfililut = 100		# default is 50
    bbb.ismmaxuc = 1		# default, OK
    bbb.mmaxu = 80		# default is 25

    bbb.svrpkg="nksol"
    bbb.premeth="ilut"
    bbb.runtim=1.0e-07              # convergence for VODPK
    bbb.rwmin=1.0e-11               # convergence for NEWTON
    bbb.ftol=1.0e-8         # convergence for NKSOL
    bbb.iscolnorm=3
    bbb.mfnksol=3
    bbb.scrit=1.e-3
    bbb.nmaxnewt=20
    bbb.itermx=30
    # Jacobian increments --
    bbb.xrinc=2
    bbb.xlinc=3
    bbb.yinc=2
    bbb.delpy=1.0e-07
    # vodpk parameters --
    bbb.jacflg=1
    bbb.jpre=1
    bbb.rtolv=1.e-4

    bbb.isteon=1
    bbb.istion=1
    bbb.isnion=1
    bbb.isnion[2:]=0
    bbb.isupon=1
    bbb.isupgon=0
    bbb.isngon=0
    bbb.isphion=0
    
    #bbb.kxe = 1.0	     #elec thermal conduc scale factor;now default
    #bbb.lmfplim = 1.e3	     #elec thermal conduc reduc 1/(1+mfp/lmfplim)
    #bbb.cion=3

    # Inertial neutrals
    com.nhsp = 2
    bbb.ziin[1] = 0.
    bbb.isngon[0] = 0
    bbb.isupgon[0] = 1


    # Fixed Impurities
    if (impFrac>1e-8):
        bbb.isimpon = 2
        bbb.afracs = impFrac
    else:
        bbb.isimpon = 0

        
   
    bbb.b0=b0
        

    if (fluxLimit):
        bbb.flalfe = 0.21 #1.0 # electron parallel thermal conduct. coeff
        bbb.flalfi = 0.21 #1.0 # ion parallel thermal conduct. coeff
        bbb.flalfv = 1.0  # ion parallel viscosity coeff
        bbb.flalfgx = 1.0  # neut. gas in poloidal direction
        bbb.flalfgy = 1.0 # neut. gas in radial direction
        bbb.flalftgx = 1.0 # neut power in poloidal direction
        bbb.flalftgy = 1.0 # neut power in radial direction
        bbb.lgmax = 0.4  # max scale for gas particle diffusion
        bbb.lgtmax = 0.4 # max scale for gas thermal diffusion
        bbb.flalftgx = 1.0		#limit x thermal transport
        bbb.flalftgy = 1.0		#limit y thermal transport
        bbb.flalfvgx = 1.0		#limit x neut visc transport
        bbb.flalfvgy = 1.0		#limit y neut visc transport
        bbb.flalfvgxy = 1.0		#limit x-y nonorthog neut visc transport
        bbb.isplflxlv = 0# 1  #=0, flalfv not active at ix=0 & nx;=1 active all ix
        bbb.isplflxlgx = 0#1 #=0, flalfgx not active at ix=0 & nx;=1 active all ix
        bbb.isplflxlgxy = 0# 1 #=0, flalfgxy not active at ix=0 & nx;=1 active all ixv
        bbb.isplflxlvgx = 0# 1 #=0, flalfvgx not active at ix=0 & nx;=1 active all ix
        bbb.isplflxlvgxy = 0# 1 #=0, flalfvgxy not active at ix=0 & nx;=1 active all ix
        bbb.iswflxlvgy = 1 #=0, flalfvgy not active at iy=0 & ny;=1 active all iy
        bbb.isplflxltgx = 0# 1 #=0, flalfvgx not active at ix=0 & nx;=1 active all ix
        bbb.isplflxltgxy = 0# 1 #=0, flalfvgxy not active at ix=0 & nx;=1 active all ix
        bbb.iswflxltgy = 1 #=0, flalfvgy not active at iy=0 & ny;=1 active all iy
        bbb.alfkxe=0.		#reduce K_|| if |bbb.te[bbb.ix+1]-bbb.te[bbb.ix]|<bbb.alfkxe*bbb.te[bbb.ix]
        bbb.alfkxi=0.		#reduce K_|| if |bbb.ti[bbb.ix+1]-bbb.ti[bbb.ix]|<bbb.alfkxi*bbb.ti[bbb.ix]
        bbb.alfeqp=0.01		#reduce temp equilibration for Te~Ti
        bbb.rkxecore = 10.	#reduce bbb.kxe in core bbb.up to bbb.rkxecore with parab
        bbb.isplflxl=0		#=0, bbb.flalfe,i not active at bbb.ix=0 & com.nx
        bbb.iswflxlgy = 0		#=0 turns off flxlim on walls
        bbb.iswflxlvgy = 0		#=0 turns off flxlim on walls
        bbb.iswflxltgy = 0		#=0 turns off flxlim on walls
        bbb.isplflxlgx = 0		#=0 turns off flxlim on plates
        bbb.isplflxlvgx = 0		#=0 turns off flxlim on plates
        bbb.isplflxltgx = 0		#=0 turns off flxlim on plates


        
    
    ##-set flat initial profiles                                                                                 
    bbb.allocate()                                                                                             
    bbb.tes=10*bbb.ev                                
    bbb.tis=10*bbb.ev                                                                                          
    bbb.nis=7e19                                                                                               
    bbb.ngs=7e19                                                                                               
    bbb.ups=0



def calculate_particle_flux(beam_power=10e6, beam_energy=90e3):

    eV_to_joules = 1.602e-19  
    energy_joules = beam_energy * eV_to_joules
    particle_flux = beam_power / energy_joules
    current =    particle_flux * eV_to_joules
    return particle_flux, current

particle_flux, current = calculate_particle_flux()
current = round(current)
print("Current is :", current)

def setBoundaryConditions(ncore= 1.2e20,  pcoree=2.5e6, pcorei=2.5e6, recycp=0.98, recycw=1.0,owall_puff=0.0, pfr_puff=0.0, dis = 1.8):

    bbb.isnicore[0] = 1    #=3 gives uniform density and I=curcore
    bbb.ncore[0] = ncore     #hydrogen ion density on core
    #bbb.isybdryog = 0#1       #=1 uses orthog diff at iy=0 and iy=ny bndry
    #bbb.curcore[0] = phi_BC

    bbb.isnwcono = 3           #=3 for (1/n)dn/dy = 1/lyni
    bbb.nwomin[0] = 1.e16 # 1.e14 # 1.e12 # 
    bbb.nwimin[0] = 1.e16 # 1.e14 # 1.e12 #
    bbb.lyni[1] = 0.02              #iy=ny+1 density radial scale length (m)
    bbb.lyni[0] = 0.02             #iy=0 density radial scale length

    bbb.isnwconi = 3                # switch for private-flux wall
    

    bbb.iflcore = 1         #flag; =0, fixed Te,i; =1, fixed power on core
    #bbb.tcoree = 200.       #core Te if iflcore=0
    #bbb.tcorei = 200.       #core Ti if iflcore=0
    bbb.pcoree = pcoree # .625e6      #core elec power if iflcore=1
    bbb.pcorei = pcorei # .625e6      #core ion  power if iflcore=1

    bbb.isextrnw=0  # extrapolation com.b.c. for density is OFF # base 0,   (0:nxm+1,0:nym+1,0:4)
    bbb.isnwcono[0]=3
    bbb.lyni=0.1    # fixed scale length, bbb.lyni

    
    bbb.isextrtw=0
    bbb.isextrtpf=0
    #bbb.istewc =  3          # =3 ditto for Te on vessel wall
    #bbb.istiwc =  3          # =3 ditto for Ti on vessel wall
    bbb.lyte = 0.02  # scale length for Te bcemacs 
    bbb.lyti = 0.02  # scale length for Ti bc
   

    bbb.isupcore = 0          #=1 sets d(up)/dy=0
    bbb.isupss=  0
    bbb.isupwo = 2          # =2 sets d(up)/dy=0
    bbb.isupwi = 2          # =2 sets d(up)/dy=0
    bbb.isplflxl = 0 # 1    #=0 for no flux limit (te & ti) at plate
    bbb.isngcore[0]=0       #set neutral density gradient at core bndry
    bbb.recycm = -1.0		# mom BC at plates:up(,,2) = -recycm*up(,,1)

    # private-flux wall plasma boundary conditions  --
    #bbb.isextrnpf=0 # extrapolation com.b.c. for density is OFF # base 0,   (0:nxm+1,0:nym+1,0:4)
    #bbb.isnwconi[0]=3       # fixed scale length
    
    #bbb.istepfc=3   # fixed scale length, bbb.lyte
    #bbb.istipfc=3   # fixed scale length, bbb.lyti

    
    bbb.matwso[0] = 1               # =1 --> make the outer wall recycling.
    bbb.matwsi[0] = 1               # =1 --> make the inner wall recycling.
    
    bbb.recycp[0] = recycp    # outer and inner wall recycling, R_N
    bbb.recycw[0] = recycw    # recycling coeff. at wall
    
    bbb.isrecmon = 1
    #bbb.kxe = 1.0		#elec thermal conduc scale factor;now default
    #bbb.lmfplim = 1e20 # 1.e3		#elec thermal conduc reduc 1/(1+mfp/lmfplim)

    # set plate albedoes
    bbb.albedolb[0,0]=0.99
    bbb.albedorb[0,0]=0.99

    # sheath parameters:
    bbb.bcei=2.5
    bbb.bcee=4.0
    bbb.travis[0] = 1.
    bbb.parvis[0] = 1.


    # Neutral gas properties
    com.ngsp=1
    bbb.ineudif=2		# pressure driven neutral diffusion
    bbb.ngbackg = 1.e14 # 1.e15 # 1.e12 #  # background gas level (1/m**3)
    bbb.isupgon[0]=1
    bbb.isngon[0]=0
    com.nhsp=2
    bbb.ziin[com.nhsp-1]=0
    
    bbb.gcfacgx = 1.            # sets plate convective gas flux
    bbb.gcfacgy = 1.            # sets wall convective gas flux
    bbb.cngfx=1.
    bbb.cngfy=1.		#turn-on grad[T_g] flux if =1
    bbb.cngflox=0.
    bbb.cngfloy=0.   	#turn-on drift with ions if =1
    
    bbb.eion = 5.		#birth energy of ions
    bbb.ediss = 10.		#dissoc. energy lost from elecs [bbb.eion=2*bbb.ediss]
    # Parallel neutral momentum equation
    
    if [bbb.isupgon[0] == 1] :
        bbb.isngon=0
        com.ngsp=1
        com.nhsp=2
        bbb.ziin[1]=0
        # The following are probably default, set them anyway to be sure
        bbb.cngmom=0
        bbb.cmwall=0
        bbb.cngtgx=0
        bbb.cngtgy=0
        bbb.kxn=0
        bbb.kyn=0



    #Divertor gas puff
    bbb.nwsor = 1  	            # number of wall sources
    bbb.matwso[0] = 1               # =1 --> make the outer wall recycling.
    bbb.matwsi[0] = 1               # =1 --> make the inner wall recycling.
    bbb.wgaso[0]=1e3  #-large number here forces the source cover the whole outer wall
    bbb.wgasi[0]=1e3
    bbb.albdsi = 1.0
    bbb.albdso = 1.0
    bbb.recycw = 1.0
    
   #-outer wall
    bbb.nwsor=2
    bbb.igaso[1]= owall_puff  #-total puff strength [A]
    bbb.xgaso[1] = dis  #-source center poloidal location [m]
    bbb.wgaso[1] = 0.04 #-source width [m]
    bbb.issorlb[1] = 0  #-measure poloidal distance from inner plate
    
    #ybbb.igaso = 0.0
#-inner wall
    bbb.igasi[1]= 0e-1  #-total pump strength [A]
    bbb.xgasi[1] = 0.3  #-source center poloidal location [m]     
    bbb.wgasi[1] = 0.3  #-source width [m]
    bbb.issorlb[1] = 0  #-measure poloidal distance from outer plate

    # plate boundary conditions
    #bbb.isplflxl=0  # turn off flux limits at plate
    # Currents and potential parameters
    bbb.isphion=0
    # Atomic physics packages
    ##**********************************************************************
    ##*****# NOTE SPECIAL SETUP FOR ehr2.dat FILE REQUIRED IN RUN DIRECTORY
    com.istabon=10	#Here use ehr5.dat via a soft link ehr2.dat --> ehr5.dat
                        #in working directory for UEDGE_V70902 and earlier.
			#For versions beyond UEDGE_V70902, setting 
			#com.istabon=17 should load ehr5.dat directly, assuming
			#it is available
    bbb.isrecmon = 1                # recombination is ON
    bbb.ediss = 2 * bbb.eion        # dissociation energy loss is ON

    # magnetic field scale factor:
    bbb.b0=1.

    # classical cross-field flux coefficients:
    bbb.cfjp2=0.
    bbb.cfjpy=0.    # diamagnetic current
    bbb.cf2dd=0.
    bbb.cfydd=0.    # diamagnetic drift
    bbb.cf2ef=0.
    bbb.cfyef=0.    # E flx.x B drift
    bbb.cfbgt=0.            # B flx.x grad_T heat flux

def setimpmodel(impmodel=False, sput_factor=1.0):

    if (impmodel):
        # Impurity gas
        com.ngsp = 2
        bbb.isngon[1] = 1
        bbb.recycp[1] = 3.e-3	#about the limit
        bbb.ngbackg[1] = 1e12
        bbb.recycw[1] = 0.01	#recycle lithium
        
        bbb.isimpon = 6
        bbb.isofric = 1		#Use general bbb.friction force expression
        bbb.cfparcur = 1.	#scale fac for bbb.fqp=parcurrent from fmombal
        com.nzsp[0]=3
	#bbb.nusp_imp = 3
        
        		
        bbb.isnion[2:6]= 1   
        bbb.n0g[1] = 1.e17
        bbb.isupgon[1] = 0		
        bbb.recycp[1:6] = 1.e-10		
        bbb.recycw[1:6] = 1.e-10	       
        bbb.ngbackg[1]=1.e10 	  
        bbb.recycw[2:6]=1.e-10

        bbb.isnicore[2:5] = 0   #=0 for api.zero flux
        bbb.isupcore[2:5] = 3	#=3 gives bbb.fmiy=0
        bbb.isnwcono[2:5] = 3	#use dni/com.dy=-bbb.ni/bbb.lyni[2]
        bbb.nwomin[2:5] = 1e13	#min bbb.ni for bbb.isnwcono=3
        bbb.nwimin[2:5] = 1e13	#min bbb.ni for bbb.isnwconi=3
        ##bbb.ncore[2:5] = 1.e14	# trace level of Li on core bdry if isnicore[2:5]
        bbb.n0[2:5] = 1.e17     #global density normalization
        bbb.inzb = 4		#exponent of bkg imp source
        bbb.nzbackg = 1.e12     #background density for impurities
        api.nzsor = 1


        bbb.allocate()				
        bbb.minu[com.nhsp:com.nhsp+3] = 7.    
        bbb.ziin[com.nhsp:com.nhsp+3] = array([1, 2, 3])    
        bbb.znuclin[0:com.nhsp] = 1	       
        bbb.znuclin[com.nhsp:com.nhsp+3] = 3
        bbb.nzbackg=1.e10		      
        bbb.n0[com.nhsp:com.nhsp+3]=1.e17
        
        #bbb.inzb=2		      
        #bbb.isbohmms=0		      
        #bbb.isnicore[com.nhsp:com.nhsp+3] = 1 
        #bbb.ncore[1:5] = 1e12  # Li core density BC
        
        #bbb.recycc[1:5]=1.e-10	        
        #bbb.curcore[com.nhsp:com.nhsp+3] = 0.0
        #bbb.isnwcono[com.nhsp:com.nhsp+3] = 3 
        #bbb.isnwconi[com.nhsp:com.nhsp+3] = 3
        #bbb.nwimin[com.nhsp:com.nhsp+3] = 1.e7
        #bbb.nwomin[com.nhsp:com.nhsp+3] = 1.e7
        bbb.kye = 0.5		#chi_e for radial elec energy diffusion
        bbb.kyi = 0.5		#chi_i for radial ion energy diffusion
        bbb.difni[2:5] =  0.5
        bbb.difni2[2:5] = 0.5
        bbb.travis[2:5] = 1.0		#eta_a for radial ion momentum diffusion
        bbb.parvis[2:7] = 1.0	       

        
        bbb.ismctab = 2         # use Braams' api.rate tables
        com.mcfilename = "b2frates_Li_v4_mod3"
        
        com.isrtndep=1
	#bbb.cion=3
        bbb.isph_sput[1]=1
        bbb.isch_sput[1]=1	# Haasz/Davis sputtering model
        bbb.crmb=bbb.minu[0]	# set mass of bombarding particles
        fhaasz=sput_factor
        bbb.fchemylb=1.e-5
        bbb.fchemyrb=1.e-5
        bbb.fphysylb=1.0
        bbb.fphysyrb=sput_factor
        bbb.fchemygwi=1.e-5
        bbb.fchemygwo=1.e-5
        bbb.isybdryog=1


       # bbb.nwsor = 2
       # bbb.igspsoro[bbb.nwsor-1] = 2
       # bbb.igspsori[bbb.nwsor-1] = 2
       # bbb.albdso[bbb.nwsor-1] = 0.99
       # bbb.albdsi[bbb.nwsor-1] = 0.99
       # bbb.albedorb[1,0] = 1.0

def drift(btry=65.):
    bbb.isphion=1

    bbb.newbcl=1      #Sheath boundary condition (bcee, i) from current equation
    bbb.newbcr=1
    bbb.b0=btry
                       #=1 for normal direction B field
    bbb.rsigpl=1.e-8    #anomalous cross field conductivity

    bbb.cfjhf =1.      #turn on heat flow from current (fqp)
    bbb.cfjve =1.      #makes vex=vix-cfjve*fqx
    bbb.cfjpy = 0
    bbb.cfjp2 = 0
    
    bbb.isfdiax=1     #Factor to turn on diamagnetic contribution to sheath
    bbb.cfqydbo = 1
    bbb.cfydd = 0
    bbb.cf2dd = 0

    bbb.cftdd = 1
    bbb.cfyef= 1.0     #EXB drift in y direction
    bbb.cftef = 1
    bbb.cf2ef=1.0     #EXB drift in 2 direction
    bbb.cfybf=1.0     #turns on vycb - radial Grad B drift
    bbb.cf2bf = 1
    bbb.cfqybf = 1
    bbb.cfq2bf = 1

    
    bbb.cfqybbo=0     #turn off Grad B current on boundary
    bbb.cfniybbo = 0
    bbb.cfeeydbo = 0
    
    
    bbb.cfniydbo = 1
    bbb.cfeeydbo = 1
    bbb.cfeixdbo = 1
    bbb.cfeexdbo = 1
    bbb.cfqym = 1 

   
    
 



def setDChi(kye=0.7, kyi=0.2, difni=0.5, nonuniform=False):
    
    if (nonuniform == False):
        print("Setting uniform transport coefficients")
        bbb.kye=kye
        bbb.kyi=kyi
        bbb.difni=difni
        bbb.dif_use=0.0
        bbb.kye_use=0.0
        bbb.kyi_use=0.0
        bbb.vy_use=0.0
        
    else:
        print("NON-uniform transport coefficients")
        bbb.isbohmcalc = 0
        
        #bbb.facbee=1.0
        #bbb.facbei=1.0
        #bbb.facbni=1.0

        bbb.dif_use[0:com.nx+2,0:com.ny+2] = bbb.difni[0] # base 0,   (0:nx+1,0:ny+1,1:nisp)
        bbb.kye_use[0:com.nx+2,0:com.ny+2] = bbb.kye # base 0,   (0:nx+1,0:ny+1)
        bbb.kyi_use[0:com.nx+2,0:com.ny+2] = bbb.kyi # base 0,   (0:nx+1,0:ny+1)

        bbb.difni[0]=0.0
        bbb.kye=0.0
        bbb.kyi=0.0


        bbb.nphygeo()

#Dn 
        profparam=5e-3
        rprof = np.zeros(com.ny+2)
        rprof[com.iysptrx:com.ny+2] = 0.50*np.exp((com.yyc[com.iysptrx:com.ny+2]-com.yyc[com.iysptrx])/profparam) 
        rprof[0:com.iysptrx] = 0.5
        #rprof[com.iysptrx-1:com.iysptrx+2] = 0.3
        
#Electron energy, chi_e
        profparam2=4e-3
        rprof2 = np.zeros(com.ny+2)
        rprof2[com.iysptrx:com.ny+2] = 0.4*np.exp((com.yyc[com.iysptrx:com.ny+2]-com.yyc[com.iysptrx])/profparam2) 
        rprof2[0:com.iysptrx] = 1.5
        rprof2[com.iysptrx-1:com.iysptrx+2] = 0.4
        
#Ion energy, chi_i
        profparam3=4.7e-3
        rprof3 = np.zeros(com.ny+2)
        rprof3[com.iysptrx:com.ny+2] = 0.3*np.exp((com.yyc[com.iysptrx:com.ny+2]-com.yyc[com.iysptrx])/profparam3) 
        rprof3[0:com.iysptrx] = 1.5
        rprof3[com.iysptrx-1:com.iysptrx+2] = 0.3

#-clip it to a constant value
#real 

        dmax=2.0
        dmax2=6
        dmax3=3
        for iii in range(0,com.ny+2):
            rprof[iii]=min(rprof[iii],dmax)
            rprof2[iii]=min(rprof2[iii],dmax2)
            rprof3[iii]=min(rprof3[iii],dmax3)

        for iii in range(0,com.nx+2):
            bbb.dif_use[iii,0:com.ny+2,0]=rprof # base 0,   (0:nx+1,0:ny+1,1:nisp)
           # bbb.dif_use[iii,0:com.ny+2,1]=rprof
            #bbb.dif_use[iii,0:com.ny+2,2]=rprof
          #  bbb.dif_use[iii,0:com.ny+2,3]=rprof
            
            bbb.kye_use[iii,0:com.ny+2]= rprof3# use same for e and i rprof2
            bbb.kyi_use[iii,0:com.ny+2]=rprof3

      
