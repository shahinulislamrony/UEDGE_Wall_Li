#!/bin/bash

#SBATCH --job-name=coupling_uedge_heat        # Name of the job
#SBATCH --partition=serial                    # Partition to submit to (adjust based on your cluster)
#SBATCH --time=48:00:00                       # Maximum runtime (48 hours in this case)
#SBATCH --output=coupling_uedge_heat_output.log  # File to save standard output
#SBATCH --error=coupling_uedge_heat_error.log    # File to save standard error

# Email Notifications
#SBATCH --mail-type=ALL                       # Send email on job start, end, and failure
#SBATCH --mail-user=john@gmail.com            # Replace with your email address 

# Number of CPU Cores (adjust as needed)
#SBATCH --ntasks=1                            # Number of tasks (1 for single-threaded Python script)
#SBATCH --cpus-per-task=1                     # Number of CPU cores per task

# Memory Allocation (adjust as needed)
#SBATCH --mem=4G                              # Memory per node (4 GB in this case)

# Job Environment
#SBATCH --export=ALL                          # Export all environment variables to the job

export OPENBLAS_NUM_THREADS=1                 # Limit OpenBLAS to a single thread

# Load Python Module (if required by your cluster)
module load python/3.10                       # Load Python module (adjust version if needed)

# Activate Virtual Environment (if applicable)
# source /path/to/your/venv/bin/activate      # Uncomment if using a virtual environment

# Run Python Script
python3 coupling_UEDGE_heat.py                # Run your Python script (ensure the file has .py extension)
