from uedge import *
from uedge.hdf5 import *
from uedge.rundt import *
import uedge_mvu.plot as mp
import uedge_mvu.utils as mu
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from runcase import *

setGrid()
setPhysics(impFrac=0,fluxLimit=True)
setDChi(kye=0.5, kyi=0.5, difni=0.35,nonuniform = False)
setBoundaryConditions(ncore = 7.78e19, pcoree=4.0e6, pcorei=4.0e6, recycp=0.95, owall_puff=0.0, dis = 1.8)
setimpmodel(impmodel=True,sput_factor=3.34)

bbb.lenpfac=120

bbb.cion=3
bbb.oldseec=0
bbb.restart=1
bbb.albdso = 0.99
bbb.albdsi = 0.99
bbb.fphysylb  = 9.51

hdf5_restore("./final_iteration.hdf5")
#hdf5_restore("./Li_all_actived.hdf5")

bbb.ftol=1e20
bbb.ftol=1e20;bbb.issfon=0; bbb.exmain()

bbb.exmain()


