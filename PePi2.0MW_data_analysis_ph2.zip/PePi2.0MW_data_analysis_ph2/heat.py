import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from matplotlib import gridspec

def atoms_vaporized_per_second():
    # Constants
    heat_of_vaporization_J_per_mol = 147000  # Heat of vaporization in J/mol
    avogadro_number = 6.022e23  # Avogadro's number (atoms per mole)
    power_in_joules_per_second = 1  # Power supplied in joules per second (1 Watt)
    
    # Calculate energy required per atom (in Joules)
    energy_per_atom = heat_of_vaporization_J_per_mol / avogadro_number
    
    # Calculate the number of atoms vaporized per second
    atoms_vaporized = power_in_joules_per_second / energy_per_atom
    
    return atoms_vaporized

# Call the function and print the result
atoms_vaporized = atoms_vaporized_per_second()
print(f"Atoms vaporized per second: {atoms_vaporized:.2e} atoms/s")

# Example usage: Let's say power supplied is 1 Watt (1 joule/second)




# physical constants
#plot_every = int(Nt / 20)
li_coeff = 2.44e-19 
Tinbc = 25 
T_air = 25
h_air = 10.0  # heat transfer coefficient (W/m^2K), vary from 5-25
h=0

T_ambient = 25  # Ambient temperature (°C)


# --- Constants ---
NA = 6.022e23        # Avogadro's number [atoms/mol]
M_Li = 0.00694       # Molar mass of lithium [kg/mol]
rho_Li = 534         # Density of lithium [kg/m³]
mass_per_atom = M_Li / NA  # Mass of a single lithium atom [kg/atom]




###UEDGE div cordinates, com.yyrb

x_data = np.array([-0.05544489, -0.0507309, -0.04174753, -0.03358036, -0.02614719, -0.01935555, -0.01316453, -0.00755603, -0.00245243, 0.00497426,
                   0.012563, 0.01795314, 0.02403169, 0.03088529, 0.03865124, 0.04744072, 0.05723254, 0.06818729, 0.0804908, 0.09413599,
                   0.10907809, 0.12501805, 0.14181528, 0.15955389, 0.17792796, 0.18716496]) 

q_data = np.array([8.516863747058426088e+04, 8.516863747058426088e+04, 8.658732672732640640e+04, 9.224168689024644846e+04,
                   1.082405806727624731e+05, 1.466081975609702058e+05, 2.283389318490335718e+05, 4.005193897112387349e+05,
                   9.411837655898311641e+05, 8.442317867601789534e+06, 6.758609278505317867e+06, 6.093629471681456082e+06,
                   5.143711920255075209e+06, 4.166083592164705973e+06, 3.367501593478952069e+06, 2.760775028947197832e+06,
                   2.298189146693516523e+06, 1.918289905024330597e+06, 1.605707128312068060e+06, 1.355246104763937416e+06,
                   1.158708622615067521e+06, 1.007663975185001036e+06, 8.828309174558679806e+05, 7.124721239178314572e+05,
                   3.894704975398445386e+05, 3.894704975398445386e+05])

fd = np.array([1.23173559e+20, 1.29929799e+20, 4.75669280e+20, 1.71093429e+21,
       5.25733877e+21, 1.38562829e+22, 3.20425642e+22, 6.81334027e+22,
       1.57264730e+23, 5.48542846e+23, 4.18983017e+23, 3.65616816e+23,
       3.51310492e+23, 3.59207011e+23, 3.55861661e+23, 3.28458848e+23,
       2.84877267e+23, 2.36499248e+23, 1.92061373e+23, 1.54896157e+23,
       1.24520115e+23, 9.93699443e+22, 7.71861549e+22, 5.44196641e+22,
       3.06817010e+22, 2.03999365e+22])

P_sput = np.array([0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 0.00000000e+00,
       0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 1.77005355e+18,
       3.63334532e+20, 2.16782622e+22, 1.70514044e+22, 1.52385634e+22,
       1.33668047e+22, 1.05411854e+22, 7.00420808e+21, 4.22580926e+21,
       2.66872542e+21, 1.89350203e+21, 1.53106909e+21, 1.39751843e+21,
       1.42022285e+21, 1.56827530e+21, 1.75214262e+21, 1.65312794e+21,
       8.70903960e+20, 0.00000000e+00])

Yield = P_sput/fd

def eval_Li_evap_at_T_Cel(temperature):
    a1 = 5.055  
    b1 = -8023.0
    xm1 = 6.939 
    tempK = abs(temperature) + 273.15

    if np.any(tempK <= 0):
        raise ValueError("Temperature must be above absolute zero (-273.15°C).")

    vpres1 = 760 * 10**(a1 + b1/tempK)  
    
    sqrt_argument = xm1 * tempK
    if np.any(sqrt_argument <= 0):
        raise ValueError(f"Invalid value for sqrt: xm1 * tempK has non-positive values.")

    fluxEvap = 1e4 * 3.513e22 * vpres1 / np.sqrt(sqrt_argument)  
    return fluxEvap

    # Incident ion flux [ions/m²/s]

def sputtering_flux(Y=0.1, Gamma_i = 1e23):
    return Gamma_i * Y  # Atoms/m²/s

def flux_Li_Ad_atom(final_temperature, YpsYad=1, eneff=0.9, A=1e-7):
    yadoyps = YpsYad  # ratio of ad-atom to physical sputtering yield
    eneff = eneff  # effective energy (eV), 0.09
    aad = A  # cont
    kB = 1.3806e-23
    eV = 1.6022e-19
    tempK = final_temperature + 273.15
    #fd = 1e23 #bbb.fnix[com.nx,:,0]*np.cos(com.angfx[com.nx,:])/com.sxnp[com.nx,:]
    fluxAd = fd*yadoyps/(1 + aad*np.exp(eV*eneff/(kB*tempK)))

    return fluxAd

def solve_heat_equation_2d(Lx, Ly, Nx, Ny, dt, Nt, boundary_conditions, graphite_x_pos, graphite_alpha, h, T_ambient):
    dx = Lx / (Nx - 1)
    dy = Ly / (Ny - 1)
    thickness = graphite_x_pos # 2mm
    print("Li thickness is mm:", thickness*1e3)
    Li_thickness = (graphite_x_pos)*dx # initial thickness 
    print("Li thickness is m:", Li_thickness)
    Li_thickness = Li_thickness * np.ones(Ny)
    #Li_thickness_init = 1e-3  
    #Li_thickness = Li_thickness_init * np.ones(Ny) 
    
    area = dx * dy
    Total_area = area * thickness*Ny
    volume = Total_area*(thickness*dx) 
    density_lithium = 534
    mass = density_lithium * volume
    
    print("mass in g is :", mass*1e3)
    
    T = np.zeros((Ny, Nx))
    T[:] = 25
    temp_surf = []
    no_itera = []
    q_x = np.zeros((Ny, Nx))
    q_y = np.zeros((Ny, Nx))
    Li_thickness_history = []
    time_history = []


    for n in range(Nt):
        T_new = T.copy()
        
        for i in range(1, Nx-1):
            for j in range(1, Ny-1):
                if i < graphite_x_pos:
                    Kappa_Li = Li_thermal_conductivity(T[j, i])  
                    Cp_Li = specific_heat_Cp(T[j, i]) 
                    rho = Li_rho(T[j,i])
                    alpha_current = 1 / (rho * Cp_Li) #Cp_Li)
                else:
                    Kappa_C = C_thermal_conductivity(T[j, i])  
                    C_Cp = C_specific_heat(T[j,i])
                    alpha_current = 1 / (rho_C * C_Cp)
                
           
                kappa_ip = Li_thermal_conductivity(T[j, i+1]) if i < graphite_x_pos else C_thermal_conductivity(T[j, i+1])
                kappa_im = Li_thermal_conductivity(T[j, i-1]) if i < graphite_x_pos else C_thermal_conductivity(T[j, i-1])
                
     
                dT_dx = (T[j, i+1] - T[j, i-1]) / (2 * dx)
                dT_dy = (T[j+1, i] - T[j-1, i]) / (2 * dy)
                
              
                term_x = (kappa_ip * (T[j, i+1] - T[j, i]) / dx**2) - (kappa_im * (T[j, i] - T[j, i-1]) / dx**2)
                term_y = (kappa_ip * (T[j+1, i] - T[j, i]) / dy**2) - (kappa_im * (T[j, i] - T[j-1, i]) / dy**2)

               
                T_new[j, i] = T[j, i] + alpha_current * dt * (term_x + term_y)

                
                q_x[j, i] = -kappa_ip * dT_dx
                q_y[j, i] = kappa_ip * dT_dy
        
 
        try:
            evap_flux = eval_Li_evap_at_T_Cel(T_new[:, 1]) 
            L_f = np.where(T_new[:, 1] == 180, 3.0e3 / 6.94e-3, 0.0) 
            q_latent =  0#(mass*L_f)/dx # W/m2
            T_new[:, 0] = T[:, 1] + ((q_data - (2.26e-19 * evap_flux) - q_latent ) * dx) / thermal_conductivity
            heat_flux_Li_surface = (q_data - (2.26e-19 * evap_flux) - q_latent)
            
        except ValueError as e:
            print(f"Error calculating left boundary: {e}")
            T_new[:, 0] = T[:, 1] + boundary_conditions['left'](np.linspace(0, Lx, Nx), dx)

            
        T_new[0, :] = T_new[1, :]
        T_new[-1, :] = T_new[-2, :]
        T_new[:, -1] = T_new[:, -2]

        for j in range(Ny):
            thickness = Li_thickness[j]
            if thickness > 1e-9:
                T_local = T_new[j, 0]  # scalar at surface
                rho_Li = Li_rho(T_local)
                evap_flux = eval_Li_evap_at_T_Cel(T_local)
                cp = specific_heat_Cp(T_local)
                evap_flux = eval_Li_evap_at_T_Cel(T_local)
                sput_flux = P_sput[j] #sputtering_flux(Y=0.1)
                fluxAd= flux_Li_Ad_atom(T_local,YpsYad=2.7)[j]
                total_flux_atoms = evap_flux + sput_flux +fluxAd # Atoms/m²/s
                mass_loss_rate = total_flux_atoms * mass_per_atom  # kg/m²/s
                d_thickness = mass_loss_rate * dt / rho_Li  # m
                Li_thickness[j] = max(thickness - d_thickness, 0)
                
                if n % 500 == 0 or n == Nt - 1:
                    Li_thickness_history.append(Li_thickness.copy())
                    time_history.append(n * dt)


          
            
        
        max_change = np.max(np.abs(T_new - T))
        temp_surface = np.max(T_new[:, 1])  
        temp_surf.append(temp_surface)
        no_it = n
        no_itera.append(no_it)
        
        T = T_new.copy()  
        
        if max_change < 1e-5:
            print(f"Convergence achieved at time step {n*dt} s with maximum change {max_change:.2e}")
            break
        plot_every = int(Nt / 20)

        if (n % plot_every == 0) or (n == Nt-1):
             plt.clf()
             plt.figure(figsize=(10, 4))
             
             plt.subplot(1, 2, 1)
             x = np.linspace(0, Lx, Nx)
             y = np.linspace(0, Ly, Ny)
             X, Y = np.meshgrid(x, y)
            # plt.contourf(X, Y, T, cmap='inferno') 
            # plt.colorbar(label='Temperature (°C)')
             contour = plt.contourf(X, Y, T, cmap='inferno')
             cbar = plt.colorbar(contour)   
             cbar.set_label('Temperature (°C)', fontsize=14)
             cbar.ax.tick_params(labelsize=12)
             cbar.set_label('Temperature (°C)', fontsize=14) 
             cbar.ax.tick_params(labelsize=12)    
             plt.title(f'Temperature at t={n*dt:.3f}s')
             plt.xlabel('x (m)')
             plt.ylabel('y (m)')
             plt.xticks(fontsize=14)
             plt.yticks(fontsize=14)
             plt.axvline(x=graphite_x_pos*dx, color='g', linestyle='--', label='Graphite Position')
             plt.legend()
             plt.tight_layout()

             plt.subplot(1, 2, 2)
             y_vals = np.linspace(0, Ly, Ny)
             Li_thickness_mm = Li_thickness * 1e3  # convert to mm
             plt.plot(Li_thickness_mm, y_vals, 'b--', linewidth=2)
             sc = plt.scatter(Li_thickness_mm, y_vals, c=Li_thickness, cmap='Blues', s=40, edgecolors='k')
             sc = plt.scatter(Li_thickness_mm, y_vals, c=Li_thickness, cmap='inferno', s=40,  edgecolors='k', vmin=0, vmax=0.005)

             plt.colorbar(sc, label='Li Thickness (m)')
             plt.title('T$_{Li-surface}$ (m)', fontsize=14)
             plt.xlabel('Thickness (mm)', fontsize=14)
             plt.xticks(fontsize=14)
             plt.yticks(fontsize=14)
             #plt.ylabel('y (m)')
             plt.xlim(0, np.max(Li_thickness_mm) * 1.1 if np.max(Li_thickness_mm) > 0 else 1e-5)
             plt.ylim(0, Ly)
             plt.grid()
             plt.tight_layout()
             plt.savefig(f"Li_dynamics_t{n*dt:.3f}s.jpg", dpi=300)
             plt.show()
             

             thickness_array = np.array(Li_thickness_history)  # shape: [len(time_history), Ny]
             time_array = np.array(time_history)  # shape: [len(time_history)]
             plt.figure(figsize=(5, 3))
             for j in range(thickness_array.shape[1]):
                 plt.plot(time_array, thickness_array[:, j]*1e3, label=f'j = {j}')
                 plt.xlabel('Time [s]',fontsize=14)
                 plt.ylabel('Li Thickness [m]',fontsize=14)
                 plt.title('Time History of Li Thickness at Each j')
                 plt.legend(loc='upper right', bbox_to_anchor=(1.15, 1.0))
                 plt.ylim([0, 5.2])
                 plt.xlim([0, 5])
                 plt.xticks(fontsize=14)
                 plt.yticks(fontsize=14)
                 plt.grid(True)
                 #plt.tight_layout()
                 #plt.show()
                 
             if thickness_array.shape[1] <= 20:
                plt.legend(loc='upper right', ncol=3, fontsize=8)
             else:
                #plt.legend().set_visible(False)
                plt.legend(loc='best', ncol=3, fontsize=8)
                plt.grid(True)
                plt.tight_layout()
                plt.show()


             thickness_array = np.array(Li_thickness_history)  # shape: [len(time_history), Ny]
             time_array = np.array(time_history)  # shape: [len(time_history)]

             plt.figure(figsize=(5, 3))
             special_styles = {
                 7: 'r--',   # red dashed
                 8: 'g-.',  # green dash-dot
                 9: 'b:',   # blue dotted
                 10: 'm-'    # magenta solid (thicker line can be added)
                 }

             for j in range(thickness_array.shape[1]):
                if j in special_styles:
                    plt.plot(time_array, thickness_array[:, j]*1e3, special_styles[j], label=f'j = {j}', linewidth=2.5)
                else:
                    plt.plot(time_array, thickness_array[:, j]*1e3, label=f'j = {j}', linewidth=1)

             plt.xlabel('Time [s]', fontsize=14)
             plt.ylabel('Li Thickness [mm]', fontsize=14)  # Changed unit to match scaling (1e3)
             plt.title('Time History of Li Thickness at Each j')
             plt.ylim([0, 5.2])
             plt.xlim([0, 5])
             plt.xticks(fontsize=14)
             plt.yticks(fontsize=14)
             plt.grid(True)

             if thickness_array.shape[1] <= 20:
                plt.legend(loc='upper right', ncol=3, fontsize=8, bbox_to_anchor=(1.15, 1.0))
             else:
                plt.legend(loc='best', ncol=3, fontsize=6)

             plt.tight_layout()
             plt.show()


        
        
        


    return T, no_itera, temp_surf, heat_flux_Li_surface, q_x, q_y

# Parameters
Lx = 0.005   # Length of the plate in x-direction (meters)
Ly = x_data[-1] - x_data[0] # Length of the plate in y-direction (meters)
Nx = 10# len(q_data)*1 #20     # Number of spatial points in x-direction
Ny = len(q_data)      # Number of spatial points in y-direction

dx = Lx / (Nx - 1)
dy = Ly / (Ny - 1)

print('dx is:', dx)
print('Nx is:', Nx)


Lx = 0.005
Nx = 10
dx = Lx/(Nx-1)
Lx = 0.05
Nx = int(Lx / dx) + 1
dx = Lx / (Nx - 1)  

print('dx is:', dx)
print('Nx is:', Nx)

#Li property
thermal_conductivity = 64  # W/(m·K)

#  https://doi.org/10.1080/00319104.2019.1636377
def Li_rho(T_C):
    """Density as a function of temperature (T in Celsius)."""
    T_K = T_C + 273.15  # Convert Celsius to Kelvin
    return 562 - 0.10 * T_K

def Li_thermal_conductivity(T_C):
    T_K = T_C + 273.15  # Convert Celsius to Kelvin
    if 200 < T_K < 453: 
        return 44 + 0.02019 * T_K + 8037 / T_K
    else:
        return 33.25+ 0.0368 * T_K + 1.096e-5 * (T_K)**2


def specific_heat_Cp (T):
    T_K = T + 273.15  # Convert Celsius to Kelvin
    if 200 < T_K < 453: 
        return (-6.999e8/(T_K)**4 + 1.087e4/(T_K)**2 + 3.039 + 5.605e-6*(T_K)**2)*1e3
    else:
      #  return 21.42 + 0.05230 * T_K + 1.371e-5 * (T_K)**2
        return (1.044e5/(T_K)**2 - 135.1/(T_K) + 4.180)*1e3

#def C_thermal_conductivity(T):   
  
#     return  134 - 0.1074 * T + 3.719e-5 * T**2

###Andrei Khodak data for NSTX-U, 02/19/2025
def C_specific_heat(T):

    Cp = -0.000000 * T**4 + 0.000003 * T**3 - 0.004663 * T**2 + 3.670527 * T + 630.194408
    return Cp

def C_thermal_conductivity(T):
    # Fitted polynomial for K
    K = 0.000000 * T**4 - 0.000000 * T**3 + 0.000086 * T**2 - 0.106014 * T + 105.106589
    return K


Kappa_C =    C_thermal_conductivity(500)

print("Graphite Kappa at 500 is: ", Kappa_C)

rho_C = 2200
C_Cp = 710
alpha_graphite = Kappa_C / (rho_C * C_Cp)  # Thermal diffusivity of graphite

##Run for 3 seconds 
dt = 1e-4     # Time step size (seconds)
t_sim = 5e-0
Nt = int(t_sim/dt)  # 100    # Number of time steps

graphite_x_pos = int(Nx/10) #int(0.01 * scale_factor)

scale_factor = 1000  # To convert meters to millimeters for example
#graphite_x_pos = 0.01 #int(0.01 * scale_factor)  
#graphite_x_pos = int(Nx * 0.0001)  # Position of the graphite layer starting point (90%, of the x-axis)


# Parameters
kappa = 85  # Thermal conductivity
rho = 534    # Density
C_p = 4200    # Specific heat capacity
delta_x =  Lx / (Nx - 1)  # Spatial step size
delta_x =  Ly / (Ny - 1)  # Spatial step size
delta_t = dt  # Time step size

Ny_data = len(q_data)
q_data = np.interp(np.linspace(0, 1, Ny), np.linspace(0, 1, Ny_data), q_data)

# Boundary condition functions
def left_boundary(x,dx):
    # Use q_data directly, since it's in W/m² and is applied to the boundary, q*dy/k
    return np.interp(y, np.linspace(0, Ly, len(q_data)), q_data)*dx / thermal_conductivity  

def right_boundary(y,T_ambient):
    return T_ambient 

def bottom_boundary(x, h, T_ambient, dx):
     return T_ambient + (h * (T_ambient - 0)) * dx / 0.025 
  
def top_boundary(x, h, T_ambient, dx):
    return T_ambient + (h * (T_ambient - 0)) * dx / 0.025  

boundary_conditions = {
    'left': left_boundary,
    'right': right_boundary,
    'bottom': bottom_boundary,
    'top': top_boundary
}



# Solve the heat equation
T = solve_heat_equation_2d(Lx, Ly, Nx, Ny, dt, Nt, boundary_conditions, graphite_x_pos, alpha_graphite, h, T_ambient)

# Prepare the mesh grid
x = np.linspace(0, Lx, Nx)
y = np.linspace(0, Ly, Ny)
X, Y = np.meshgrid(x, y)

# Plot the temperature distribution in lithium and graphite layers 
plt.figure(figsize=(6, 4))

plt.contourf(X, Y, T[0], cmap='inferno') 
#plt.colorbar(label='Temperature (°C)')
cbar = plt.colorbar()
cbar.set_label('Temperature (°C)', fontsize=18)
cbar.ax.yaxis.set_tick_params(labelsize=14)
plt.xlabel('x (m)', fontsize = 18)
plt.ylabel('y (m)', fontsize = 18)
plt.title('Temperature Distribution')
plt.axvline(x=graphite_x_pos * dx, color='g', linestyle='--', label='Graphite Position')
plt.annotate('Graphite Region', xy=(graphite_x_pos * dx, 0.002), 
             xytext=(graphite_x_pos * dx + 0.0005, 0.1* Ly),
             arrowprops=dict(facecolor='black',width=2),
             fontsize=20, color='red')

plt.legend()
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.tight_layout()
plt.savefig('final_2D.png', dpi=300)
#plt.show()




plt.figure(figsize=(8, 6))
plt.plot(np.linspace(0, Ly, len(q_data)), q_data / 1e6, label='Heat flux', color='red', marker='o')
plt.xlabel('y (m)', fontsize=16)
plt.ylabel('q$_{div}$ (MW/m²)',fontsize=16)
plt.grid()
plt.legend()
plt.title('UEDGE Heat Flux on LM surface')
plt.tight_layout()
plt.savefig('heat_flux.png', dpi=300)
#plt.show()

plt.figure(figsize=(8, 6))
plt.plot(Y[:,0], T[0][:,1], label='Temperature on surface',color ='b',marker='o')
plt.ylabel('Surface temp (°C)',fontsize=16)
plt.xlabel('y (m)',fontsize=16)
plt.legend()
plt.grid(True)
plt.savefig('final_Tsurf.png', dpi=300)
#plt.show()

fig, ax1 = plt.subplots(figsize=(8, 6))

# Plot heat flux on primary y-axis
color = 'tab:red'
ax1.set_xlabel('y (m)', fontsize=16)
ax1.set_ylabel('Heat flux (MW/m²)', fontsize=16, color=color)
ax1.plot(Y, q_data / 1e6, color=color, marker='o', label='Heat flux')
ax1.tick_params(axis='y', labelcolor=color)
ax1.grid(True)
ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis
color = 'tab:blue'
ax2.set_ylabel('Temperature (°C)', fontsize=16, color='blue')
ax2.plot(Y[:,0], T[0][:,1], color='blue', label='Temperature')
ax2.tick_params(axis='y', labelcolor='blue')

fig.tight_layout()  # adjust the layout
#ax1.legend(loc='upper left')
ax2.legend(loc='upper right')
plt.title('Heat Flux and Temperature on Surface')
plt.savefig('dual_axis_plot.png', dpi=300)
plt.show()


t_sim = np.multiply(T[1],dt)
np.savetxt('Tmax.txt', T[2])
np.savetxt('tsim.txt', t_sim)
np.savetxt('final.npy', T[0])
np.savetxt('q_surface', T[3])

# T, no_itera, temp_surf, q_x, q_y

plt.figure(figsize=(6, 4))
plt.plot(np.multiply(T[1],dt), T[2], color='red', marker='o')
plt.ylabel('T$_{surf}^{max}$ (°C)', fontsize=16)
plt.xlabel('t$_{simulation}$ (s)',fontsize=16)
plt.grid()
#plt.legend()
plt.ylim([0,800])
#plt.title('U on LM surface')
plt.tight_layout()
plt.savefig('tsurf_max.png', dpi=300)
#plt.show() 
 

plt.figure(figsize=(6, 4))
color = 'tab:red'
plt.plot(Y, q_data / 1e6, color=color, marker='o', label='Heat flux')
plt.ylim([0, 5])
plt.grid()
plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize =16)
plt.ylabel('Heat flux (MW/m²)', fontsize=16)
plt.tight_layout()  # adjust the layout
#plt.title('Heat Flux and Temperature on Surface')
plt.savefig('heat.png', dpi=300)
#plt.show()

plt.figure(figsize=(5,3))
plt.plot(np.multiply(T[1], dt), T[2], color='red')
plt.ylabel('T$_{surf}^{max}$ (°C)', fontsize=16)
plt.xlabel('t$_{simulation}$ (s)', fontsize=16)
plt.grid() 
plt.tick_params(axis='both', labelsize=16)
plt.ylim([0, 900])
plt.xlim([0, 5])
plt.tight_layout()
plt.savefig('tsurf_max.eps', format='eps', dpi=300)
plt.show()

plt.figure(figsize=(5, 3))
color = 'tab:red'
plt.plot(Y, q_data / 1e6, color=color, marker='o', label='Heat flux')
plt.ylim([0, 10])
plt.xlim([0, 0.25])
plt.grid()
plt.tick_params(axis='both', labelsize=16)
plt.xlabel('y (m)', fontsize=16)
plt.ylabel('Heat flux (MW/m²)', fontsize=16)
plt.tight_layout()  # Adjust the layout
plt.savefig('heat.eps', format='eps', dpi=300)
plt.show()





plt.figure(figsize=(5, 3), constrained_layout=True)
color = 'tab:red'
plt.plot(Y, q_data / 1e6, color=color, marker='o', label='Heat flux')  # convert to MW/m²
plt.ylim([0, 10])
plt.xlim([0, 0.25])
plt.grid()
plt.tick_params(axis='both', labelsize=16)
plt.xlabel('y (m)', fontsize=16)
plt.ylabel('Heat flux (MW/m²)', fontsize=16)
# Optional: show legend if desired
# plt.legend(fontsize=14, loc='upper right')
plt.savefig('heat.eps', format='eps', dpi=300, bbox_inches='tight')
plt.show()
